# Week 1 — A universe, unevenly connected

Reproduce the Social Graphs course post from the frozen 26 August 2026 dataset.
Source: https://sunelehmann.com/socialgraphs2026-web/data/
Post: https://birkir-freyr.github.io/social-graphs/

Use Python 3.10 or newer. Extract the archive, open a terminal in this folder,
then run:

    python3 -m venv .venv
    .venv/bin/python -m pip install -r requirements.txt
    .venv/bin/python analysis/build_week1.py

This generates site/data/week1.json and site/assets/week1-degrees.svg, checking
the graph counts, degree distributions, components, and removal experiment.
Optionally open the included notebook with:

    .venv/bin/jupyter lab analysis/week1.ipynb

On Windows, use .venv\Scripts\python.exe in place of .venv/bin/python and
.venv\Scripts\jupyter.exe in place of .venv/bin/jupyter.
