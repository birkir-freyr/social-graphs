# Week 2 — Even superheroes have more popular friends

Reproduce the Social Graphs course post from the frozen 26 August 2026 dataset.
Source: https://sunelehmann.com/socialgraphs2026-web/data/
Post: https://birkir-freyr.github.io/social-graphs/weeks/week2.html

Use Python 3.10 or newer. Extract the archive, open a terminal in this folder,
then run:

    python3 -m venv .venv
    .venv/bin/python -m pip install networkx==3.4.2
    .venv/bin/python analysis/build_week2.py

On Windows, use .venv\Scripts\python.exe in place of .venv/bin/python.

This generates site/data/week2.json and site/data/week2-null-trials.csv. It
recalculates the exact sampling expectations and 100 graphs for each of two
nulls. Every labelled degree is checked after each degree-preserving shuffle.
The included Week 1 JSON supplies layout coordinates only; measurements come
from the original node roster and edge list. No network access or GitHub login
is needed after installing NetworkX. Seeds and source hashes are exported.
